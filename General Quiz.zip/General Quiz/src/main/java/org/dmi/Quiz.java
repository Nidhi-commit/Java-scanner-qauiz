package org.dmi;

import java.util.Scanner;

class MainQuiz {

    public static void main(String args[]){
        int marks = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Do you want to play Quiz: y?n -->");
        String input = scanner.nextLine();
        if(input.equalsIgnoreCase("y")){
            System.out.println("Welcome to DMI quiz... Let's Play ");
            System.out.println();
            System.out.println("Q.1. What is the capital of India? ");
            System.out.println("a.) Calcutta    b.) Delhi");
            System.out.println("c.) Hyderabad   d.) Mumbai");
            input = scanner.nextLine();
            if(input.equalsIgnoreCase("b")){
                marks = marks+10;
                System.out.println("Congrats! Your answer is correct!".concat("You've earned 10 marks."));
                System.out.println();
                System.out.println("Let's move to the next question." );
                System.out.println();
            }
            else{
                System.out.println("Your answer is wrong. Let's try another: ");
            }
            System.out.println("Q.2. Where is the 'Silk City' of India located?");
            System.out.println("a.) Assam   b.) Punjab");
            System.out.println("c.) Bihar   b.) Tamil Nadu");
            input=scanner.nextLine();
            if(input.equalsIgnoreCase("c")) {
                marks = marks+10;
                System.out.println("Congrats! Your answer is correct!".concat("You've earned 10 marks."));
                System.out.println();
                System.out.println("Let's move to the next question." );
                System.out.println();
            }
                else {
                System.out.println("Your answer is wrong. Let's try another:");
            }
            System.out.println("You've Scored a : "+marks);  //autoboxing - when string appends with some other datatype

        }
        else
            System.out.println("Thank You! See you next time..");

    }

}

